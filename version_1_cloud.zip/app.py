# app.py
from flask import Flask, request, render_template, send_from_directory
import subprocess, os, glob

app = Flask(__name__)
os.makedirs('variants', exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    plate_input = ""
    results = []
    filename = ""
    message = ""
    show_all = False

    if request.method == 'POST':
        plate_input = request.form['plate'].strip()
        show_all = 'show_all' in request.form

        try:
            # Run the C++ binary with the plate input
            subprocess.run(['./tag', plate_input], check=True)

            # Find the most recently generated output file
            latest_file = max(glob.glob('variants/*.txt'), key=os.path.getctime)
            filename = latest_file.replace("\\", "/")  # Normalize path

            # Parse the output file
            with open(latest_file, 'r') as f:
                lines = f.readlines()

            for line in lines:
                if line.startswith('#') or not line.strip():
                    continue
                try:
                    parts = line.strip().split()
                    variant = parts[1]
                    score = float(parts[2])
                    if not show_all and score < 0.001:
                        continue
                    results.append({
                        'variant': variant,
                        'score': score,
                        'flag': 'Top' if score >= 0.4 else ''
                    })
                except:
                    continue  # ✅ Properly inside except block

            message = f"Generated {len(results)} variants for '{plate_input}'."
        except Exception as e:
            message = f"❌ Error: {str(e)}"

    return render_template('index.html',
                           plate_input=plate_input,
                           results=results,
                           filename=filename,
                           message=message,
                           show_all=show_all)

@app.route('/variants/<path:filename>')
def download(filename):
    return send_from_directory('variants', filename, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
