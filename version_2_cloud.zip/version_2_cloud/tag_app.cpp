// tag_app.cpp
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <map>
#include <set>
#include <ctime>
#include <algorithm>
#include <filesystem>

struct VariantScore {
    std::string variant;
    double score;
};

std::map<char, std::string> getSubstitutions() {
    return {
        {'A',"A4"}, {'B',"B8"}, {'C',"CG"}, {'D',"D"},  {'E',"E3"},
        {'G',"G6C"},{'H',"HN"},{'I',"I1"},{'L',"L1"},{'M',"MN"},
        {'N',"NHM"},{'O',"O0"},{'Q',"Q0"},{'S',"S5"},{'T',"T7"},
        {'U',"UV"},{'V',"VUY"},{'W',"W"},{'X',"X"},{'Y',"YV"},
        {'Z',"Z2"},{'0',"0O"},{'1',"1I"},{'2',"2Z"},{'3',"3E"},
        {'4',"4A"},{'5',"5S"},{'6',"6G"},{'7',"7T"},{'8',"8B3"},
        {'9',"9"}
    };
}

std::map<std::pair<char,char>, double> getConfusionProb() {
    return {
        {{'1','I'},0.8}, {{'I','1'},0.8},
        {{'8','B'},0.6}, {{'B','8'},0.6},
        {{'8','3'},0.3}, {{'3','8'},0.3},
        {{'0','O'},0.7}, {{'O','0'},0.7},
        {{'U','V'},0.5}, {{'V','U'},0.5},
        {{'V','Y'},0.4}, {{'Y','V'},0.4},
        {{'Y','U'},0.3}, {{'U','Y'},0.3},
        {{'N','M'},0.4}, {{'M','N'},0.4},
        {{'G','C'},0.3}, {{'C','G'},0.3}
    };
}

void generateVariants(const std::string& input, std::set<std::string>& results,
                      std::string current = "", int pos = 0) {
    static auto subs = getSubstitutions();
    if (pos == input.size()) {
        results.insert(current);
        return;
    }
    char c = toupper(input[pos]);
    if (subs.count(c)) {
        for (char alt : subs[c]) {
            generateVariants(input, results, current + alt, pos + 1);
            if (results.size() >= 5000) return;
        }
    } else {
        generateVariants(input, results, current + c, pos + 1);
    }
}

double computeScore(const std::string& input, const std::string& variant) {
    static auto probMap = getConfusionProb();
    double score = 1.0;
    for (size_t i = 0; i < input.size() && i < variant.size(); ++i) {
        char o = toupper(input[i]), v = toupper(variant[i]);
        if (o == v) continue;
        auto it = probMap.find({o, v});
        if (it != probMap.end()) score *= it->second;
        else { score = 0.0; break; }
    }
    return score;
}

std::string getTimestampedFilename(const std::string& base, const std::string& tag) {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    char buf[64];
    snprintf(buf, sizeof(buf), "%s/%s_%04d%02d%02d_%02d%02d.txt",
             base.c_str(), tag.c_str(),
             1900+ltm->tm_year, 1+ltm->tm_mon, ltm->tm_mday,
             ltm->tm_hour, ltm->tm_min);
    return std::string(buf);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: ./tag <LICENSE_PLATE>\n";
        return 1;
    }

    std::string tag = argv[1];
    std::filesystem::create_directory("variants");

    std::set<std::string> variants;
    generateVariants(tag, variants);

    std::vector<VariantScore> scored;
    for (auto& v : variants)
        scored.push_back({v, computeScore(tag, v)});

    std::sort(scored.begin(), scored.end(),
              [](auto& a, auto& b) {
                  if (a.score != b.score) return a.score > b.score;
                  return a.variant < b.variant;
              });

    std::string fname = getTimestampedFilename("variants", tag);
    std::ofstream out(fname);
    out << "# TAG VARIANTS FOR: " << tag << "\n"
        << "# Generated " << scored.size() << " variants\n\n";

    for (size_t i = 0; i < scored.size(); ++i)
        out << (i+1) << ". " << scored[i].variant << "\t" << scored[i].score << "\n";

    out.close();

    std::cout << "✅ Saved " << scored.size() << " variants to: " << fname << "\n"
              << "🔟 First 10 variants:\n";

    for (int i = 0; i < std::min(10, (int)scored.size()); ++i)
        std::cout << (i+1) << ". " << scored[i].variant << "\t" << scored[i].score << "\n";

    return 0;
}
