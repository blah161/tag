# /var/www/blah161_pythonanywhere_com_wsgi.py

import sys
import os

# Set the path to your Flask app's directory
path = '/home/blah161/tag_cloud_flask'
if path not in sys.path:
    sys.path.append(path)
os.chdir(path)

# Import the Flask app
from app import app as application
